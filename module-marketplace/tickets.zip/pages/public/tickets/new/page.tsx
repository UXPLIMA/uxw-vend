"use client";

import { useState, useEffect } from "react";
import { Link, useRouter } from "@/core/sdk/navigation";
import { Button, Label, Textarea, NativeSelect, buttonClassName } from "@/core/sdk/ui";
import { Footer, Navbar } from "@/core/sdk/layout";
import { ThemeComponentSlot } from "@/core/sdk/theme";
import { useSession } from "next-auth/react";
import { useTranslations } from "next-intl";
import { writeError } from "@/core/sdk";

interface Department {
    id: string;
    name: string;
    description: string | null;
    color: string | null;
}

export default function NewTicketPage() {
    const { data: session } = useSession();
    const router = useRouter();
    const t = useTranslations('tickets');
    const commonT = useTranslations('common');
    const [departments, setDepartments] = useState<Department[]>([]);
    const [departmentsLoaded, setDepartmentsLoaded] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [formData, setFormData] = useState({
        subject: "",
        content: "",
        departmentId: "",
        priority: "MEDIUM",
    });

    useEffect(() => {
        fetch("/api/v1/tickets/departments")
            .then((res) => res.json())
            .then((data) => setDepartments(Array.isArray(data) ? data : data.departments || []))
            .catch(console.error)
            .finally(() => setDepartmentsLoaded(true));
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            const res = await fetch("/api/v1/tickets", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData),
            });

            const failed = await writeError(res, t('createTicketFailed'), t);
            if (failed) {
                throw new Error(failed);
            }

            const ticket = await res.json();
            router.push(`/support/${ticket.id}`);
        } catch (err) {
            setError(err instanceof Error ? err.message : commonT('somethingWentWrong'));
        } finally {
            setLoading(false);
        }
    };

    if (!session?.user) {
        return (
            <div className="min-h-screen flex flex-col bg-muted">
                <ThemeComponentSlot name="Hero" />
                <Navbar />
                <main className="container mx-auto px-4 py-6 flex-1">
                    <div className="bg-card rounded-xl p-8 text-center">
                        <p className="text-muted-foreground mb-4">{t('loginToCreate')}</p>
                        <Link href="/auth/login" className={buttonClassName("default", "default")}>{t('login')}</Link>
                    </div>
                </main>
                <Footer />
            </div>
        );
    }

    return (
        <div className="min-h-screen flex flex-col bg-muted">
            <ThemeComponentSlot name="Hero" />
            <Navbar />

            <main className="container mx-auto px-4 py-6 flex-1">
                {/* Breadcrumb */}
                <div className="text-sm text-muted-foreground mb-4">
                    <Link href="/" className="hover:text-primary">{commonT('home')}</Link>
                    <span className="mx-2">/</span>
                    <Link href="/support" className="hover:text-primary">{t('title')}</Link>
                    <span className="mx-2">/</span>
                    <span className="text-foreground">{t('newTicket')}</span>
                </div>

                <h1 className="text-2xl font-bold text-foreground mb-6">{t('createNewTicket')}</h1>

                <div className="bg-card rounded-xl border border-border p-6 max-w-3xl">
                    {departmentsLoaded && departments.length === 0 ? (
                        <div className="text-center py-10">
                            <p className="font-medium text-foreground">{t('noDepartmentsTitle')}</p>
                            <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">{t('noDepartmentsHelp')}</p>
                        </div>
                    ) : (<>
                    {error && (
                        <div role="alert" className="mb-4 p-3 bg-destructive/10 border border-destructive/20 text-destructive rounded-lg text-sm">
                            {error}
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <Label htmlFor="department">{t('department')} *</Label>
                            <NativeSelect
                                id="department"
                                value={formData.departmentId}
                                onChange={(e) => setFormData({ ...formData, departmentId: e.target.value })} className="w-full mt-1"
                                required
                            >
                                <option value="">{t('selectDepartment')}</option>
                                {departments.map((dept) => (
                                    <option key={dept.id} value={dept.id}>
                                        {dept.name}
                                    </option>
                                ))}
                            </NativeSelect>
                        </div>

                        <div>
                            <Label htmlFor="priority">{t('priority')}</Label>
                            <NativeSelect
                                id="priority"
                                value={formData.priority}
                                onChange={(e) => setFormData({ ...formData, priority: e.target.value })} className="w-full mt-1"
                            >
                                <option value="LOW">{t('low')}</option>
                                <option value="MEDIUM">{t('medium')}</option>
                                <option value="HIGH">{t('high')}</option>
                                <option value="URGENT">{t('urgent')}</option>
                            </NativeSelect>
                        </div>

                        <div>
                            <Label htmlFor="subject">{t('subject')} *</Label>
                            <input
                                id="subject"
                                type="text"
                                value={formData.subject}
                                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                                className="w-full mt-1 px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                                placeholder={t('briefDescription')}
                                required
                            />
                        </div>

                        <div>
                            <Label htmlFor="content">{t('message')} *</Label>
                            <Textarea
                                id="content"
                                value={formData.content}
                                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                                placeholder={t('describeIssue')}
                                rows={8}
                                required
                            />
                        </div>

                        <div className="flex gap-3">
                            <Button type="submit" disabled={loading}>
                                {loading ? t('creating') : t('createTicket')}
                            </Button>
                            <Link href="/support" className={buttonClassName("outline", "default")}>{t('cancel')}</Link>
                        </div>
                    </form>
                    </>)}
                </div>
            </main>

            <Footer />
        </div>
    );
}
