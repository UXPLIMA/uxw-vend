"use client";


import { useTranslations } from "next-intl";
import { useState, useEffect } from "react";
import { Button, Card, CardContent, CardHeader, CardTitle, Input, Label, useConfirm, useSiteCurrency } from "@/core/sdk/ui";
import { Loader2, Plus, X, Trash2, Gift, Copy, Check, ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";

interface GiftCode {
    id: string;
    code: string;
    value: number;
    isRedeemed: boolean;
    redeemedBy: { username: string } | null;
    redeemedAt: string | null;
    expiresAt: string | null;
    createdAt: string;
}

export default function GiftCodesPage() {
    const { format: money } = useSiteCurrency();
    const t = useTranslations("store");
    const commonT = useTranslations("common");
    const { confirm } = useConfirm();
    const [codes, setCodes] = useState<GiftCode[]>([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [saving, setSaving] = useState(false);
    const [value, setValue] = useState("10");
    const [count, setCount] = useState("1");
    const [expiresAt, setExpiresAt] = useState("");
    const [copiedId, setCopiedId] = useState<string | null>(null);
    // Codes are generated in batches, so this table is one of the few here
    // that genuinely reaches thousands of rows. It reads a page at a time.
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    const fetchCodes = async (targetPage = page) => {
        const res = await fetch(`/api/v1/gift-codes?page=${targetPage}`);
        if (res.ok) {
            const data = await res.json();
            setCodes(data.giftCodes || []);
            setTotalPages(Math.max(1, data.pages || 1));
        }
        setLoading(false);
    };

    // eslint-disable-next-line react-hooks/set-state-in-effect
    useEffect(() => { fetchCodes(page); }, [page]);

    const generate = async (e: React.FormEvent) => {
        e.preventDefault();
        setSaving(true);
        const res = await fetch("/api/v1/gift-codes", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                value: parseFloat(value),
                count: parseInt(count),
                expiresAt: expiresAt ? new Date(expiresAt).toISOString() : undefined,
            }),
        });
        if (res.ok) {
            const data = await res.json();
            toast.success(`Generated ${data.count} gift codes`);
            setShowForm(false);
            setPage(1);
            fetchCodes(1);
        } else toast.error(t("adm_giftCodeFailed"));
        setSaving(false);
    };

    const deleteCode = async (id: string) => {
        const ok = await confirm({
            title: t("gc_deleteTitle"),
            message: t("gc_deleteConfirm"),
            confirmText: t("gc_delete"),
            variant: "danger",
        });
        if (!ok) return;
        try {
            const res = await fetch(`/api/v1/gift-codes/${id}`, { method: "DELETE" });
            if (!res.ok) {
                toast.error(t("gc_deleteError"));
                return;
            }
            toast.success(t("gc_deletedToast"));
            fetchCodes();
        } catch {
            toast.error(t("gc_deleteError"));
        }
    };

    const copyCode = (code: string, id: string) => {
        navigator.clipboard.writeText(code);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
    };

    if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div>;

    return (
        <>
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold">{t("adm_giftCodes")}</h1>
                    <p className="text-muted-foreground">{t("adm_codesTotal", { total: codes.length, available: codes.filter(c => !c.isRedeemed).length })}</p>
                </div>
                <Button onClick={() => setShowForm(!showForm)}>
                    {showForm ? <><X className="w-4 h-4 mr-2" /> {t("adm_cancel")}</> : <><Plus className="w-4 h-4 mr-2" /> {t("adm_generate")}</>}
                </Button>
            </div>

            {showForm && (
                <Card className="mb-6">
                    <CardHeader><CardTitle>{t("adm_generateGiftCodes")}</CardTitle></CardHeader>
                    <CardContent>
                        <form onSubmit={generate} className="space-y-4">
                            <div className="grid md:grid-cols-3 gap-4">
                                <div>
                                    <Label>{t("adm_valueDollar")}</Label>
                                    <Input aria-label={t("adm_valueDollar")} type="number" step="0.01" min="0.01" value={value} onChange={(e) => setValue(e.target.value)} required />
                                </div>
                                <div>
                                    <Label>{t("adm_quantity")}</Label>
                                    <Input aria-label={t("adm_quantity")} type="number" min="1" max="100" value={count} onChange={(e) => setCount(e.target.value)} required />
                                </div>
                                <div>
                                    <Label>{t("adm_expiresAt")}</Label>
                                    <Input aria-label={t("adm_expiresAt")} type="datetime-local" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />
                                </div>
                            </div>
                            <Button type="submit" disabled={saving}>
                                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Gift className="w-4 h-4 mr-2" />}
                                {t("adm_generateCodes", { count: parseInt(count) || 1 })}
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            )}

            <Card>
                <CardContent className="p-0">
                    {codes.length === 0 ? (
                        <p className="text-muted-foreground text-center py-8">{t("adm_noGiftCodesYet")}</p>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead>
                                    <tr className="border-b">
                                        <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">{t("adm_code")}</th>
                                        <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">{t("adm_value")}</th>
                                        <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">{t("adm_status")}</th>
                                        <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">{t("adm_redeemedBy")}</th>
                                        <th className="text-right py-3 px-4 font-medium text-muted-foreground text-sm">{t("adm_actions")}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {codes.map((code) => (
                                        <tr key={code.id} className="border-b last:border-0 hover:bg-muted/50">
                                            <td className="py-3 px-4">
                                                <code className="font-mono text-sm bg-muted px-2 py-0.5 rounded">{code.code}</code>
                                            </td>
                                            <td className="py-3 px-4 font-medium">{money(Number(code.value))}</td>
                                            <td className="py-3 px-4">
                                                <span className={`text-xs px-2 py-1 rounded ${code.isRedeemed ? "bg-muted text-muted-foreground" : "bg-green-100 text-green-700"}`}>
                                                    {code.isRedeemed ? t("adm_redeemed") : t("adm_available")}
                                                </span>
                                            </td>
                                            <td className="py-3 px-4 text-sm text-muted-foreground">
                                                {code.redeemedBy?.username || "-"}
                                            </td>
                                            <td className="py-3 px-4 text-right">
                                                <div className="flex items-center justify-end gap-1">
                                                    <Button aria-label={commonT("copy")} variant="ghost" size="sm" onClick={() => copyCode(code.code, code.id)}>
                                                        {copiedId === code.id ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                                                    </Button>
                                                    <Button aria-label={commonT("delete")} variant="ghost" size="sm" className="text-destructive" onClick={() => deleteCode(code.id)}>
                                                        <Trash2 className="w-3 h-3" />
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {totalPages > 1 && (
                        <div className="flex items-center justify-between p-4 border-t">
                            <span className="text-sm text-muted-foreground">{page} / {totalPages}</span>
                            <div className="flex gap-2">
                                <Button aria-label={commonT("previousPage")} variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(page - 1)}><ChevronLeft className="w-4 h-4" /></Button>
                                <Button aria-label={commonT("nextPage")} variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(page + 1)}><ChevronRight className="w-4 h-4" /></Button>
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>
        </>
    );
}
