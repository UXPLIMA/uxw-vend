import { NextRequest, NextResponse } from "next/server";
import { prisma, rateLimitForRole, readJsonBody } from "@/core/sdk/server";
import { auth } from "@/core/sdk/auth";

// POST /api/v1/store/coupons/validate - Check coupon validity
export async function POST(request: NextRequest) {
    const session = await auth();
    if (!session?.user) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const rl = await rateLimitForRole(
        `coupon:${session.user.id}`,
        { maxRequests: 10, windowMs: 60_000 },
        session.user.role
    );
    if (!rl.success) {
        return NextResponse.json({ error: "Too many requests" }, { status: 429 });
    }

    const jsonBody = await readJsonBody(request);
    if (jsonBody instanceof NextResponse) return jsonBody;
    const { code, subtotal } = jsonBody;

    if (!code) return NextResponse.json({ error: "Code required" }, { status: 400 });

    const coupon = await prisma.coupon.findUnique({
        where: { code: code.toUpperCase() },
    });

    if (!coupon || !coupon.isActive) {
        return NextResponse.json({ valid: false, error: "Invalid or expired coupon code" });
    }

    const now = new Date();
    if (coupon.startsAt && coupon.startsAt > now) {
        return NextResponse.json({ valid: false, error: "Invalid or expired coupon code" });
    }
    if (coupon.expiresAt && coupon.expiresAt < now) {
        return NextResponse.json({ valid: false, error: "Invalid or expired coupon code" });
    }
    if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
        return NextResponse.json({ valid: false, error: "Invalid or expired coupon code" });
    }
    if (coupon.minPurchase && subtotal && Number(subtotal) < Number(coupon.minPurchase)) {
        return NextResponse.json({ valid: false, error: `Minimum purchase: $${Number(coupon.minPurchase).toFixed(2)}` });
    }

    let discount = 0;
    if (coupon.type === "PERCENTAGE") {
        discount = (subtotal || 0) * (Number(coupon.value) / 100);
        if (coupon.maxDiscount) discount = Math.min(discount, Number(coupon.maxDiscount));
    } else {
        discount = Number(coupon.value);
    }

    return NextResponse.json({
        valid: true,
        coupon: {
            code: coupon.code,
            type: coupon.type,
            value: Number(coupon.value),
            discount: Math.round(discount * 100) / 100,
        },
    });
}
