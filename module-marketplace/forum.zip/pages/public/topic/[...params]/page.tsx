"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { useParams } from "next/navigation";
import { useRouter } from "@/core/sdk/navigation";
import { useSession } from "next-auth/react";
import DOMPurify from "dompurify";
import { toast } from "sonner";
import { Link } from "@/core/sdk/navigation";
import { Button, Card, CardContent, Textarea } from "@/core/sdk/ui";
import { Footer, Navbar } from "@/core/sdk/layout";
import { ThemeComponentSlot } from "@/core/sdk/theme";
import { ArrowLeft, ChevronLeft, ChevronRight, Pin, Lock, Eye, ThumbsUp, Send, Loader2 } from "lucide-react";
import { useRelativeTime } from "@/core/sdk/ui";
import { useTranslations } from "next-intl";

interface Post {
    id: string;
    content: string;
    createdAt: string;
    author: { id: string; username: string; avatar: string | null };
    _count: { likes: number };
}

interface Topic {
    id: string;
    title: string;
    slug: string;
    content: string;
    isPinned: boolean;
    isLocked: boolean;
    views: number;
    createdAt: string;
    author: { id: string; username: string; avatar: string | null };
    category: { id: string; name: string; slug: string; color: string | null };
    posts: Post[];
    _count: { likes: number };
}

export default function TopicDetailPage() {
    const t = useTranslations('forum');
    const router = useRouter();
    const { data: session } = useSession();
    const relativeTime = useRelativeTime();
    const params = useParams();
    // Can be { slug: ["forum","topic","3","general"], params: "3/general" } etc
    const raw = params.params || params.slug;
    const segments = typeof raw === "string" ? raw.split("/") : Array.isArray(raw) ? raw : [String(raw)];
    const topicIdx = segments.indexOf("topic");
    const topicId = topicIdx >= 0 && segments[topicIdx + 1] ? segments[topicIdx + 1] : segments[0];

    const [topic, setTopic] = useState<Topic | null>(null);
    const [loading, setLoading] = useState(true);
    const [replyContent, setReplyContent] = useState("");
    const [sending, setSending] = useState(false);
    const [liked, setLiked] = useState(false);
    const [likeCount, setLikeCount] = useState(0);
    const [postsPage, setPostsPage] = useState(1);
    const [postsPages, setPostsPages] = useState(1);
    const [restricted, setRestricted] = useState(false);

    // `isStale` lets the effect below drop a response for a page the reader has
    // already left. Action handlers call fetchTopic with no predicate: their
    // response is always the one wanted.
    const fetchTopic = (page = postsPage, isStale: () => boolean = () => false) => {
        fetch(`/api/v1/forum/topics/${topicId}?postsPage=${page}`)
            .then(async (r) => {
                if (isStale()) return null;
                if (r.status === 403) { setRestricted(true); return null; }
                return r.json();
            })
            .then((d) => {
                if (isStale()) return;
                if (d) {
                    setTopic(d.topic || null);
                    setPostsPages(d.postsPages || 1);
                }
                setLoading(false);
            })
            .catch(() => {
                if (isStale()) return;
                setLoading(false);
            });
    };

    useEffect(() => {
        let cancelled = false;
        fetchTopic(postsPage, () => cancelled);
        // Check like status
        fetch(`/api/v1/forum/topics/${topicId}/like`)
            .then((r) => r.json())
            .then((d) => {
                if (cancelled) return;
                setLiked(d.liked);
                setLikeCount(d.count);
            })
            .catch(() => {});
        return () => { cancelled = true; };
    }, [topicId, postsPage]);  // eslint-disable-line react-hooks/exhaustive-deps

    const toggleLike = async () => {
        if (!topic) return;
        if (!session?.user) {
            toast.error(t("loginToLike"));
            router.push("/auth/login");
            return;
        }
        try {
            const res = await fetch(`/api/v1/forum/topics/${topic.id}/like`, { method: "POST" });
            if (res.ok) {
                const data = await res.json();
                setLiked(data.liked);
                setLikeCount(data.count);
            } else if (res.status === 401) {
                toast.error(t("loginToLike"));
                router.push("/auth/login");
            } else {
                toast.error(t("likeError"));
            }
        } catch (err) {
            console.error("Failed to toggle like:", err);
            toast.error(t("likeError"));
        }
    };

    const submitReply = async () => {
        if (!replyContent.trim() || !topic) return;
        setSending(true);
        try {
            const res = await fetch(`/api/v1/forum/topics/${topic.id}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content: replyContent }),
            });
            if (res.ok) {
                setReplyContent("");
                fetchTopic();
            }
        } catch (err) {
            console.error("Failed to post reply:", err);
        } finally {
            setSending(false);
        }
    };

    const renderAvatar = (user: { username: string; avatar: string | null }) => (
        <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-muted-foreground font-bold text-sm flex-shrink-0">
            {user.avatar ? (
                <Image src={user.avatar} alt="" width={40} height={40} className="w-full h-full rounded-full object-cover" />
            ) : (
                user.username[0].toUpperCase()
            )}
        </div>
    );

    return (
        <div className="min-h-screen flex flex-col bg-muted">
            <ThemeComponentSlot name="Hero" />
            <Navbar />

            <main className="container mx-auto px-4 py-6 flex-1 max-w-4xl">
                <Link href="/forum" className="flex items-center gap-1 text-sm text-muted-foreground hover:text-blue-600 mb-4">
                    <ArrowLeft className="w-4 h-4" /> {t('backToForum')}
                </Link>

                {loading ? (
                    <div className="text-center py-12">
                        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground mx-auto" />
                    </div>
                ) : restricted ? (
                    <Card>
                        <CardContent className="py-12 text-center space-y-3">
                            <p className="text-muted-foreground">{t('guestViewDisabled')}</p>
                            <Link href="/auth/login" className="text-blue-600 hover:underline text-sm">{t('signIn')}</Link>
                        </CardContent>
                    </Card>
                ) : !topic ? (
                    <Card>
                        <CardContent className="py-12 text-center">
                            <p className="text-muted-foreground">{t('topicNotFound')}</p>
                        </CardContent>
                    </Card>
                ) : (
                    <>
                        {/* Topic Header */}
                        <div className="mb-6">
                            <div className="flex items-center gap-2 mb-2">
                                {topic.isPinned && <Pin className="w-4 h-4 text-blue-500" />}
                                {topic.isLocked && <Lock className="w-4 h-4 text-muted-foreground" />}
                                <h1 className="text-2xl font-bold text-foreground">{topic.title}</h1>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-muted-foreground">
                                <span
                                    className="px-2 py-0.5 rounded text-xs"
                                    style={{
                                        backgroundColor: (topic.category.color || "#6366f1") + "20",
                                        color: topic.category.color || "#6366f1",
                                    }}
                                >
                                    {topic.category.name}
                                </span>
                                <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{t('viewsCount', { count: topic.views })}</span>
                                <button
                                    onClick={toggleLike}
                                    className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${liked ? "bg-blue-100 text-blue-600" : "hover:bg-muted"}`}
                                >
                                    <ThumbsUp className={`w-3 h-3 ${liked ? "fill-blue-600" : ""}`} />
                                    {t('likesCount', { count: likeCount })}
                                </button>
                            </div>
                        </div>

                        {/* Original Post */}
                        <Card className="mb-4 border-l-4 border-l-blue-500">
                            <CardContent className="p-5">
                                <div className="flex items-center gap-3 mb-4">
                                    {renderAvatar(topic.author)}
                                    <div>
                                        <p className="font-medium text-foreground">{topic.author.username}</p>
                                        <p className="text-xs text-muted-foreground">{relativeTime(new Date(topic.createdAt))}</p>
                                    </div>
                                </div>
                                <div
                                    className="prose dark:prose-invert max-w-none text-foreground"
                                    dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(topic.content) }}
                                />
                            </CardContent>
                        </Card>

                        {/* Replies */}
                        {topic.posts.length > 0 && (
                            <div className="space-y-3 mb-6">
                                <h2 className="text-sm font-medium text-muted-foreground">{t('repliesCount', { count: topic.posts.length })}</h2>
                                {topic.posts.map((post) => (
                                    <PostCard key={post.id} post={post} renderAvatar={renderAvatar} />
                                ))}
                            </div>
                        )}

                        {/* Reply pager - a long thread arrives a page at a time */}
                        {postsPages > 1 && (
                            <nav className="flex items-center justify-center gap-3 mb-6" aria-label={t('replies', { count: topic.posts.length })}>
                                <Button
                                    variant="outline" size="icon"
                                    onClick={() => setPostsPage((p) => Math.max(1, p - 1))}
                                    disabled={postsPage <= 1}
                                    aria-label={t('previous')}
                                >
                                    <ChevronLeft className="w-4 h-4" />
                                </Button>
                                <span className="text-sm text-muted-foreground">
                                    {t('pageOf', { page: postsPage, total: postsPages })}
                                </span>
                                <Button
                                    variant="outline" size="icon"
                                    onClick={() => setPostsPage((p) => Math.min(postsPages, p + 1))}
                                    disabled={postsPage >= postsPages}
                                    aria-label={t('next')}
                                >
                                    <ChevronRight className="w-4 h-4" />
                                </Button>
                            </nav>
                        )}

                        {/* Reply Form */}
                        {!topic.isLocked ? (
                            <Card>
                                <CardContent className="p-5">
                                    <h2 className="font-medium text-foreground mb-3">{t('reply')}</h2>
                                    <Textarea
                                        value={replyContent}
                                        onChange={(e) => setReplyContent(e.target.value)}
                                        placeholder={t('writeYourReply')} aria-label={t('writeYourReply')}
                                        rows={4}
                                        className="mb-3"
                                    />
                                    <Button onClick={submitReply} disabled={sending || !replyContent.trim()}>
                                        {sending ? (
                                            <><Loader2 className="w-4 h-4 animate-spin" /> {t('posting')}</>
                                        ) : (
                                            <><Send className="w-4 h-4" /> {t('postReply')}</>
                                        )}
                                    </Button>
                                </CardContent>
                            </Card>
                        ) : (
                            <div className="text-center py-4 text-muted-foreground text-sm">
                                <Lock className="w-4 h-4 inline mr-1" /> {t('topicLocked')}
                            </div>
                        )}
                    </>
                )}
            </main>

            <Footer />
        </div>
    );
}

function PostCard({ post, renderAvatar }: { post: Post; renderAvatar: (user: { username: string; avatar: string | null }) => React.ReactNode }) {
    const relativeTime = useRelativeTime();
    const [postLiked, setPostLiked] = useState(false);
    const [postLikeCount, setPostLikeCount] = useState(post._count.likes);

    const togglePostLike = async () => {
        try {
            const res = await fetch(`/api/v1/forum/posts/${post.id}/like`, { method: "POST" });
            if (res.ok) {
                const data = await res.json();
                setPostLiked(data.liked);
                setPostLikeCount(data.count);
            }
        } catch (err) {
            console.error("Failed to toggle post like:", err);
        }
    };

    return (
        <Card>
            <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-3">
                    {renderAvatar(post.author)}
                    <div>
                        <p className="font-medium text-foreground text-sm">{post.author.username}</p>
                        <p className="text-xs text-muted-foreground">{relativeTime(new Date(post.createdAt))}</p>
                    </div>
                </div>
                <div
                    className="prose prose-sm dark:prose-invert max-w-none text-foreground mb-3"
                    dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(post.content) }}
                />
                <button
                    onClick={togglePostLike}
                    className={`flex items-center gap-1 text-xs px-2 py-1 rounded transition-colors ${postLiked ? "bg-blue-100 text-blue-600" : "text-muted-foreground hover:bg-muted hover:text-muted-foreground"}`}
                >
                    <ThumbsUp className={`w-3 h-3 ${postLiked ? "fill-blue-600" : ""}`} />
                    {postLikeCount}
                </button>
            </CardContent>
        </Card>
    );
}
