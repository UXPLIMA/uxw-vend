"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { Link } from "@/core/sdk/navigation";
import { Button, Card, CardContent, Input, LoadFailed, Skeleton, buttonClassName } from "@/core/sdk/ui";
import { PageFrame } from "@/core/sdk/layout";
import { MessageSquare, Eye, ThumbsUp, Pin, Lock, Plus, Search } from "lucide-react";
import { useRelativeTime } from "@/core/sdk/ui";
import { useTranslations } from "next-intl";

interface Category {
    id: string;
    name: string;
    slug: string;
    description: string | null;
    icon: string | null;
    color: string | null;
    _count: { topics: number };
}

interface Topic {
    id: string;
    number: number;
    title: string;
    slug: string;
    isPinned: boolean;
    isLocked: boolean;
    views: number;
    createdAt: string;
    author: { id: string; username: string; avatar: string | null };
    category: { id: string; name: string; slug: string; color: string | null };
    _count: { posts: number; likes: number };
}

export default function ForumPage() {
    const [categories, setCategories] = useState<Category[]>([]);
    const [topics, setTopics] = useState<Topic[]>([]);
    const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [searchQuery, setSearchQuery] = useState("");
    const [restricted, setRestricted] = useState(false);
    const [failed, setFailed] = useState(false);
    const [reloadKey, setReloadKey] = useState(0);
    const t = useTranslations('forum');
    const relativeTime = useRelativeTime();

    useEffect(() => {
        fetch("/api/v1/forum/categories")
            .then((r) => (r.ok ? r.json() : null))
            .then((d) => setCategories(d?.categories || []))
            .catch(() => {});
    }, []);

    useEffect(() => {
        let cancelled = false;
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setLoading(true);
        // No `limit` here on purpose: the page size is the admin's
        // `topicsPerPage` setting, which the endpoint applies.
        const params = new URLSearchParams({ page: String(page) });
        if (selectedCategory) params.set("category", selectedCategory);
        if (searchQuery) params.set("search", searchQuery);

        fetch(`/api/v1/forum/topics?${params}`)
            .then(async (r) => {
                if (cancelled) return null;
                if (r.status === 403) { setRestricted(true); return null; }
                // Any other refusal is a failure to load, not an empty forum.
                if (!r.ok) throw new Error("load failed");
                return r.json();
            })
            .then((d) => {
                if (cancelled) return;
                if (d) {
                    setTopics(d.topics || []);
                    setTotalPages(d.pages || 1);
                }
                setFailed(false);
                setLoading(false);
            })
            .catch(() => {
                if (cancelled) return;
                setFailed(true);
                setLoading(false);
            });
        return () => { cancelled = true; };
    }, [selectedCategory, page, searchQuery, reloadKey]);

    return (
        <PageFrame
            title={t('title')}
            description={t('communityDiscussions')}
            actions={(
                <Link href="/forum/new" className={buttonClassName("default", "default")}>
                    <Plus className="w-4 h-4" /> {t('newTopic')}
                </Link>
            )}
        >
            {/* Search */}
            <div className="relative max-w-md mb-6">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                    value={searchQuery}
                    onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
                    placeholder={t('searchTopics')} aria-label={t('searchTopics')}
                    className="pl-10"
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                {/* Sidebar - Categories */}
                <div className="lg:col-span-1">
                    <Card>
                        <CardContent className="p-4">
                            <h2 className="font-semibold text-foreground mb-3">{t('categories')}</h2>
                            <div className="space-y-1">
                                <button
                                    onClick={() => { setSelectedCategory(null); setPage(1); }}
                                    className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${!selectedCategory ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-muted"}`}
                                >
                                    {t('allTopics')}
                                </button>
                                {categories.map((cat) => (
                                    <button
                                        key={cat.id}
                                        onClick={() => { setSelectedCategory(cat.id); setPage(1); }}
                                        className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors flex items-center justify-between ${selectedCategory === cat.id ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-muted"}`}
                                    >
                                        <span className="flex items-center gap-2">
                                            {cat.icon && <span>{cat.icon}</span>}
                                            {cat.name}
                                        </span>
                                        <span className="text-xs text-muted-foreground">{cat._count.topics}</span>
                                    </button>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Topics List */}
                <div className="lg:col-span-4 min-w-0 space-y-3">
                    {loading ? (
                        // Drawn to the measurements of the card that
                        // replaces it. A line of text stood 120px tall
                        // against the 236px card that answers, so the
                        // topics arriving pushed the footer down by 118px.
                        // The sentence stays for a reader who is listening
                        // rather than looking.
                        <Card>
                            <CardContent className="py-12 text-center" aria-busy="true">
                                <span className="sr-only">{t('loadingTopics')}</span>
                                <Skeleton className="w-12 h-12 rounded-full mx-auto mb-3" />
                                <Skeleton className="h-6 w-56 mx-auto mb-4" />
                                <Skeleton className="h-10 w-40 mx-auto" />
                            </CardContent>
                        </Card>
                    ) : restricted ? (
                        <Card>
                            <CardContent className="py-12 text-center space-y-3">
                                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                                <p className="text-muted-foreground">{t('guestViewDisabled')}</p>
                                <Link href="/auth/login" className="text-primary hover:underline text-sm">{t('signIn')}</Link>
                            </CardContent>
                        </Card>
                    ) : failed ? (
                        <LoadFailed onRetry={() => setReloadKey((k) => k + 1)} />
                    ) : topics.length === 0 ? (
                        <Card>
                            <CardContent className="py-12 text-center">
                                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                                <p className="text-muted-foreground mb-4">{t('noTopics')}</p>
                                <Link href="/forum/new" className={buttonClassName("default", "default")}>{t('createTopic')}</Link>
                            </CardContent>
                        </Card>
                    ) : (
                        <>
                            {topics.map((topic) => (
                                <Link key={topic.id} href={`/forum/topic/${topic.number}/${topic.slug}`}>
                                    <Card className="hover:shadow-md transition-shadow cursor-pointer">
                                        <CardContent className="p-4">
                                            <div className="flex items-start gap-4">
                                                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-muted-foreground font-bold text-sm flex-shrink-0">
                                                    {topic.author.avatar ? (
                                                        <Image src={topic.author.avatar} alt="" width={40} height={40} className="w-full h-full rounded-full object-cover" />
                                                    ) : (
                                                        topic.author.username[0].toUpperCase()
                                                    )}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center gap-2 mb-1">
                                                        {topic.isPinned && <Pin className="w-3 h-3 text-primary" />}
                                                        {topic.isLocked && <Lock className="w-3 h-3 text-muted-foreground" />}
                                                        <h2 className="font-medium text-foreground truncate">{topic.title}</h2>
                                                    </div>
                                                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                                        <span>{topic.author.username}</span>
                                                        <span>·</span>
                                                        <span>{relativeTime(new Date(topic.createdAt))}</span>
                                                        {topic.category && (
                                                            <>
                                                                <span>·</span>
                                                                <span
                                                                    className="px-2 py-0.5 rounded text-xs"
                                                                    style={{
                                                                        backgroundColor: (topic.category.color || "#6366f1") + "20",
                                                                        color: topic.category.color || "#6366f1",
                                                                    }}
                                                                >
                                                                    {topic.category.name}
                                                                </span>
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-4 text-xs text-muted-foreground flex-shrink-0">
                                                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" />{topic._count.posts}</span>
                                                    <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{topic.views}</span>
                                                    <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3" />{topic._count.likes}</span>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </Link>
                            ))}

                            {/* Pagination */}
                            {totalPages > 1 && (
                                <div className="flex justify-center gap-2 pt-4">
                                    <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(page - 1)}>
                                        {t('previous')}
                                    </Button>
                                    <span className="flex items-center px-3 text-sm text-muted-foreground">
                                        {t('pageOf', { page, total: totalPages })}
                                    </span>
                                    <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(page + 1)}>
                                        {t('next')}
                                    </Button>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>
        </PageFrame>
    );
}
