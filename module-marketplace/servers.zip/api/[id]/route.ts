import { NextRequest, NextResponse } from "next/server";
import { encryptSecret, isAdmin, prisma } from "@/core/sdk/server";
import { auth } from "@/core/sdk/auth";

type RouteParams = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, { params }: RouteParams) {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (!(await isAdmin(session.user.id))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const { id } = await params;
    const body = await request.json();
    const data: Record<string, unknown> = {};
    if (body.name !== undefined) data.name = body.name;
    if (body.type !== undefined) data.type = body.type;
    if (body.host !== undefined) data.host = body.host;
    if (body.port !== undefined) data.port = body.port;
    if (body.rconPort !== undefined) data.rconPort = body.rconPort;
    if (body.rconPassword !== undefined) {
        // Encrypt at rest. Empty/null clears the field; any non-empty value
        // is wrapped via AES-256-GCM (see secret-storage.ts).
        data.rconPassword = body.rconPassword ? encryptSecret(body.rconPassword) : null;
    }
    if (body.queryPort !== undefined) data.queryPort = body.queryPort;
    if (body.isDefault !== undefined) data.isDefault = body.isDefault;
    if (body.isActive !== undefined) data.isActive = body.isActive;
    if (body.order !== undefined) data.order = body.order;
    const server = await prisma.gameServer.update({ where: { id }, data });
    return NextResponse.json({ server });
}

export async function DELETE(request: NextRequest, { params }: RouteParams) {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (!(await isAdmin(session.user.id))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const { id } = await params;
    await prisma.gameServer.delete({ where: { id } });
    return NextResponse.json({ message: "Server deleted" });
}
