"use client";

import { useState, useEffect, use } from "react";
import Image from "next/image";
import { useTranslations, useLocale } from "next-intl";
import { Link } from "@/core/sdk/navigation";
import { Card, CardContent, CardHeader, CardTitle, RoleBadge } from "@/core/sdk/ui";
import { PageFrame } from "@/core/sdk/layout";
import { Loader2, MessageSquare, FileText, ShoppingCart, ThumbsUp, Calendar } from "lucide-react";
import { dateLocaleTag } from "@/core/sdk";

interface Player {
    id: string;
    username: string;
    avatar: string | null;
    createdAt: string;
    role: {
        id: string;
        name: string;
        displayName: string;
        color: string | null;
        nameCss?: string | null;
        badgeCss?: string | null;
    } | null;
    // Only the statistics this install can actually count. A module that is
    // not installed contributes no key at all, so nothing renders a zero for it.
    _count: Record<string, number | undefined>;
    recentTopics: { id: string; title: string; slug: string; createdAt: string }[];
    linkedAccounts: { provider: string; username: string | null; avatar: string | null }[];
}

interface PageProps {
    params: Promise<{ username: string }>;
}

export default function PlayerProfilePage({ params }: PageProps) {
    const __locale = useLocale();
    const __dateTag = dateLocaleTag(__locale);
    const { username } = use(params);
    const t = useTranslations("playerProfiles");
    const [player, setPlayer] = useState<Player | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let cancelled = false;
        fetch(`/api/v1/players/${username}`)
            .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
            .then((d) => {
                if (cancelled) return;
                setPlayer(d.player);
                setLoading(false);
            })
            .catch(() => {
                if (cancelled) return;
                setLoading(false);
            });
        return () => { cancelled = true; };
    }, [username]);

    return (
        <PageFrame
            title={player?.username ?? username}
        >
            {loading ? (
                <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div>
            ) : !player ? (
                <Card><CardContent className="py-12 text-center text-muted-foreground">{t("playerNotFound")}</CardContent></Card>
            ) : (
                <>
                    {/* Profile Header */}
                    <div className="flex items-center gap-5 mb-8">
                        {(() => {
                            // The member's own picture, then whatever a linked
                            // account brought with it. This used to build a
                            // URL at mc-heads.net out of a linked Minecraft
                            // name, which is a third party this module has no
                            // business knowing about and a game this site may
                            // have nothing to do with. `LinkedAccount.avatar`
                            // is where a picture that came with an identity
                            // belongs, and whoever links the account fills it.
                            const linked = player.linkedAccounts.find((a) => a.avatar);
                            const avatarSrc = player.avatar || linked?.avatar || null;
                            if (avatarSrc) {
                                return (
                                    <Image
                                        src={avatarSrc}
                                        alt={player.username}
                                        width={80}
                                        height={80}
                                        className="w-20 h-20 rounded-xl object-cover shadow-sm"
                                    />
                                );
                            }
                            return (
                                <div className="w-20 h-20 rounded-xl shadow-sm bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-2xl font-bold">
                                    {player.username.charAt(0).toUpperCase()}
                                </div>
                            );
                        })()}
                        <div>
                            <RoleBadge role={player.role ?? null} className="mt-1" />
                            <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {t("joinDate")}: {new Date(player.createdAt).toLocaleDateString(__dateTag)}
                            </p>
                        </div>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
                        {[
                            { key: "orders", label: t("stat_orders"), value: player._count.orders, icon: ShoppingCart },
                            { key: "topics", label: t("stat_topics"), value: player._count.topics, icon: MessageSquare },
                            { key: "posts", label: t("stat_posts"), value: player._count.posts, icon: FileText },
                            { key: "comments", label: t("stat_comments"), value: player._count.comments, icon: FileText },
                            { key: "suggestions", label: t("stat_suggestions"), value: player._count.suggestions, icon: ThumbsUp },
                        ].filter((s): s is typeof s & { value: number } => s.value !== undefined).map((s) => (
                            <Card key={s.key}>
                                <CardContent className="p-3 text-center">
                                    <s.icon className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                                    <p className="text-xl font-bold">{s.value}</p>
                                    <p className="text-xs text-muted-foreground">{s.label}</p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        {/* Linked Accounts */}
                        {player.linkedAccounts.length > 0 && (
                            <Card>
                                <CardHeader><CardTitle className="text-sm">{t("linkedAccounts")}</CardTitle></CardHeader>
                                <CardContent>
                                    <div className="space-y-2">
                                        {player.linkedAccounts.map((acc) => (
                                            <div key={acc.provider} className="flex items-center gap-2 text-sm">
                                                <span className="capitalize font-medium text-foreground">{acc.provider}</span>
                                                {acc.username && <span className="text-muted-foreground">{acc.username}</span>}
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {/* Recent Topics */}
                        {player.recentTopics.length > 0 && (
                            <Card>
                                <CardHeader><CardTitle className="text-sm">{t("activity")}</CardTitle></CardHeader>
                                <CardContent>
                                    <div className="space-y-2">
                                        {player.recentTopics.map((topic) => (
                                            <Link key={topic.id} href={`/forum/topic/${topic.id}/${topic.slug}`} className="block text-sm text-foreground hover:text-primary transition-colors truncate">
                                                {topic.title}
                                            </Link>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </>
            )}
        </PageFrame>
    );
}
